class Dimension {
  //constructor(ctrs, rati, sizz) {
  constructor() {
    fill(10, 200, 200);
    circle(0, 0, 400);
    this.size = 500;
  }
}