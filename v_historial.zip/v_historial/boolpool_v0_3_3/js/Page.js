class Page {
  constructor(num) {
    this.n = num;
  }
  
  display() {
    fill("cyan");
    rect(0, 0, 100, 100);
  }
  
}