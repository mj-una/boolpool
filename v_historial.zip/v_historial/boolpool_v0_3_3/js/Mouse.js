class Mouse {
  
}