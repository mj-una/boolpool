class DotCursor {
  
  constructor() {
    
  }
  
  mov() {
    
  }
  
  display() {
    fill(255,155, 0, 100);
    circle(mouseX, mouseY, dm.dCurs);
  }
  
}