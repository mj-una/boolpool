class Buton {
  
  constructor(n) {
    this.id = n;
  }
  
  update() {
    
  }
  
  isP() {
    if (evltr.isBtn()) this.wP = true;
    else this.wP = false;
  }
  
  display() {
    
  }
}

/*
function isCanvas() {
  if (mouseX > 0 && mouseX < dim.size && mouseY > 0 && mouseY < dim.size) return true;
  else return false; 
}
  
function isBtnC() {
  if (mouseX > 0 && mouseX < dim.size && mouseY > 0 && mouseY < dim.size) return true;
  else return false;
}
  
function isBtnL() {
  if (mouseX > 0 && mouseX < dim.size && mouseY > 0 && mouseY < dim.size) return true;
  else return false;
}
  
function isBtnR() {
  if (mouseX > 0 && mouseX < dim.size && mouseY > 0 && mouseY < dim.size) return true;
  else return false;
}
*/