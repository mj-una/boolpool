class Table {
  
  constructor() {
    
  }
  
  update() {
    
  }
  
  display() {
    // backgru, areas, scores.
    p0.display();
    p1.display();
    for (let i = 0; i < 4; i++) {
      targets[i].display();
    }
  }
}