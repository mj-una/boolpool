class Collision {
  
  player() {
    
  }
  
  target() {
    
  }
  
}




function isCollisionPlayer() {
  if (dist(p1.pos, p0.pos) < dim.ballDiameter) return true;
  else return false;
}

function collisionPlayer() {
  
  
}


/*
function isCollsionTarget() {
  if (p1.isTrgt() || p0.isTrgt()) return true;
  else return 0;
}

function collisionTarget() {
  let col1, col0;
  col1 = p1.trgt();
  col0 = p0.trgt();
}
  
function isVelMin() {
  if (p1.vel == 0 && p0.vel == 0) return true;
  else return false;
}
*/

