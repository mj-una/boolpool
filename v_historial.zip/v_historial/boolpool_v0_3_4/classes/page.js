class Page {
  
  constructor(n) {
    this.id = n;
  }
  
  update() {
    
  }
  
  display() {
    
  }
  
}